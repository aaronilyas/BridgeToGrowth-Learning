import type { z } from "zod";
import type { ErrorCode } from "../shared/api.ts";
import { env } from "./env.ts";
import { guardOrigin, originAllowed } from "./localGuard.ts";
import { takeToken } from "./rate.ts";

export class HttpError extends Error {
  constructor(readonly status: number, readonly code: ErrorCode) {
    super(code);
  }
}

// O(n) in body size
// SEC: read incrementally so chunked bodies cannot bypass the configured cap
export async function readBodyCapped(req: Request, cap: number): Promise<Uint8Array> {
  const reader = req.body?.getReader();
  if (!reader) return new Uint8Array();
  const chunks: Uint8Array[] = [];
  let size = 0;
  try {
    while (true) {
      const result = await reader.read();
      if (result.done) break;
      size += result.value.byteLength;
      if (size > cap) {
        await reader.cancel();
        throw new HttpError(413, "too_large");
      }
      chunks.push(result.value);
    }
  } finally {
    reader.releaseLock();
  }
  const body = new Uint8Array(size);
  let offset = 0;
  for (const chunk of chunks) {
    body.set(chunk, offset);
    offset += chunk.byteLength;
  }
  return body;
}

export type Ctx<B> = {
  req: Request;
  ip: string;
  params: Record<string, string>;
  body: B;
};
export type RouteOpts<B> = { body?: z.ZodType<B>; rate?: { key: string; cap: number; perMin: number }; csrf?: boolean; maxBody?: number; raw?: boolean };

const JSON_HEADERS = { "content-type": "application/json", "cache-control": "no-store" };
const STRICT_CSP = "default-src 'self'; script-src 'self' 'wasm-unsafe-eval'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; font-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'";
const SECURITY_HEADERS: ReadonlyArray<readonly [string, string]> = [
  ["x-content-type-options", "nosniff"],
  ["referrer-policy", "strict-origin-when-cross-origin"],
  ["permissions-policy", "camera=(), microphone=(), geolocation=()"],
];

// O(1)
function applySecurityHeaders(headers: Headers, csp: string): void {
  headers.set("content-security-policy", csp);
  for (const [name, value] of SECURITY_HEADERS) headers.set(name, value);
}

// O(1)
// INV: 204, 205 and 304 stay bodyless so the Fetch API accepts them
// SEC: csp defaults to the strict policy
export function secureResponse(res: Response, csp: string = STRICT_CSP): Response {
  const headers = new Headers();
  for (const [name, value] of res.headers) {
    if (name === "set-cookie") continue;
    headers.append(name, value);
  }
  for (const cookie of res.headers.getSetCookie()) headers.append("set-cookie", cookie);
  applySecurityHeaders(headers, csp);
  if (res.status === 204 || res.status === 205 || res.status === 304) return new Response(null, { status: res.status, statusText: res.statusText, headers });
  return new Response(res.body, { status: res.status, statusText: res.statusText, headers });
}

export { originAllowed };

// O(n) in body size
export function json(data: unknown, status: number = 200): Response {
  return new Response(JSON.stringify(data), { status, headers: JSON_HEADERS });
}

// O(1)
// SEC: the server binds to 127.0.0.1; a missing X-Real-IP shares the local bucket
function readIp(req: Request): string {
  return req.headers.get("x-real-ip") ?? "local";
}

// O(n) in body size
// INV: check order is size, origin, rate limit, body parse, handler
// INV: raw skips body parsing so the handler reads the stream itself (multipart); size is capped by content-length here and by the handler
// INV: rate buckets are keyed by the route key
export function route<B = undefined>(opts: RouteOpts<B>, fn: (c: Ctx<B>) => Promise<Response>): (req: Request & { params?: Record<string, string> }) => Promise<Response> {
  const maxBody = opts.maxBody ?? 64 * 1024;
  return async (req) => {
    try {
      const len = Number(req.headers.get("content-length") ?? 0);
      if (len > maxBody) throw new HttpError(413, "too_large");
      const csrf = opts.csrf ?? (req.method !== "GET" && req.method !== "HEAD");
      if (csrf && !originAllowed(req.headers.get("origin"), guardOrigin())) throw new HttpError(403, "forbidden_origin");
      const ip = readIp(req);
      if (opts.rate && !takeToken(opts.rate.key, opts.rate.cap, opts.rate.perMin)) throw new HttpError(429, "rate_limited");
      let body = undefined as B;
      if (opts.body && !opts.raw) {
        const text = new TextDecoder().decode(await readBodyCapped(req, maxBody));
        let raw: unknown;
        try {
          raw = JSON.parse(text);
        } catch {
          throw new HttpError(400, "bad_request");
        }
        const r = opts.body.safeParse(raw);
        if (!r.success) throw new HttpError(400, "bad_request");
        body = r.data;
      }
      return secureResponse(await fn({ req, ip, params: req.params ?? {}, body }));
    } catch (e) {
      if (e instanceof HttpError) return secureResponse(json({ error: e.code }, e.status));
      console.error("request failed");
      return secureResponse(json({ error: "internal" }, 500));
    }
  };
}

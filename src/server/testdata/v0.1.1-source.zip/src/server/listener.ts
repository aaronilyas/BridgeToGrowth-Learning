import type { Server } from "bun";
import { env } from "./env.ts";
import { json, secureResponse } from "./http.ts";
import { SERVER_IDLE_TIMEOUT_S } from "./llm/timeouts.ts";
import { guardOrigin, localGuard, originAllowed } from "./localGuard.ts";
import { readPyodideAsset } from "./pyodideAssets.ts";

export const MAX_REQUEST_BYTES = 80 * 2 ** 20;

type ApiHandler = (req: Request & { params?: Record<string, string> }, server?: Server<UpstreamSocket>) => Promise<Response>;
export type ApiRoutes = Record<string, ApiHandler | Partial<Record<"GET" | "POST" | "PUT" | "PATCH" | "DELETE", ApiHandler>>>;
type UpstreamSocket = { url: string; inner: WebSocket | null; pending: Array<string | Buffer> };

const HASHED_CHUNK = /^\/chunk-[a-z0-9]+\.(?:js|css)$/;
const CHUNK_TYPES = ["text/javascript", "application/javascript", "text/css"];
const HASHED_FONT = /^\/[A-Za-z0-9_]+(?:-[A-Za-z0-9]+)*-[a-z0-9]{8}\.(?:woff2|woff|ttf)$/;
const FONT_TYPES = ["font/woff2", "font/woff", "font/ttf"];
const IMMUTABLE = "public, max-age=31536000, immutable";
const SKIP_REQUEST_HEADERS = new Set(["connection", "keep-alive", "proxy-connection", "transfer-encoding", "upgrade", "te", "trailer", "accept-encoding"]);

// O(n) in header count
function forwardedHeaders(src: Headers): Headers {
  const headers = new Headers();
  for (const [name, value] of src) {
    if (SKIP_REQUEST_HEADERS.has(name)) continue;
    headers.append(name, value);
  }
  headers.set("accept-encoding", "identity");
  return headers;
}

// O(n) in header count
// INV: only a production bundle chunk (chunk-<hash>.js|css, 200, JS or CSS body) or a file-loader font (<name>-<hash>.woff2|woff|ttf, 200, font body) is cached as immutable; a stale hash that falls through to the HTML document keeps Bun's headers
function cacheHashedAsset(path: string, res: Response): Response {
  if (env.NODE_ENV !== "production" || res.status !== 200) return res;
  const types = HASHED_CHUNK.test(path) ? CHUNK_TYPES : HASHED_FONT.test(path) ? FONT_TYPES : null;
  const type = (res.headers.get("content-type") ?? "").toLowerCase();
  if (types === null || !types.some((t) => type.startsWith(t))) return res;
  const headers = new Headers(res.headers);
  headers.set("cache-control", IMMUTABLE);
  return new Response(res.body, { status: res.status, statusText: res.statusText, headers });
}

// O(1) plus the upstream round trip
// INV: only paths outside `api` reach here (HTML bundle, hashed assets, dev HMR); every response leaves through secureResponse
async function proxyDocument(req: Request, upstream: URL): Promise<Response> {
  try {
    const url = new URL(req.url);
    const headers = forwardedHeaders(req.headers);
    const init: RequestInit & { proxy: false; duplex?: "half" } = { method: req.method, headers, redirect: "manual", proxy: false };
    if (req.method !== "GET" && req.method !== "HEAD") {
      init.body = req.body;
      init.duplex = "half";
    }
    const res = await fetch(new URL(url.pathname + url.search, upstream), init);
    return secureResponse(cacheHashedAsset(url.pathname, res));
  } catch {
    return secureResponse(json({ error: "internal" }, 500));
  }
}

const API_METHODS = ["GET", "POST", "PUT", "PATCH", "DELETE"] as const;

// O(n) in route count
// SEC: every API handler and the document fallback share one guard
// INV: only a request that passes the guard has its idle timeout lifted; a model call may stay quiet for the user's whole time limit, which Bun's 255s idleTimeout ceiling cannot cover, and that call's own deadline bounds it
function guardRoutes(api: ApiRoutes, token: string, portOf: () => number): ApiRoutes {
  const guard = (handler: ApiHandler): ApiHandler => async (req, server) => {
    const blocked = localGuard(req, `127.0.0.1:${portOf()}`, token);
    if (blocked) return secureResponse(blocked);
    server?.timeout(req, 0);
    return handler(req);
  };
  const guarded: ApiRoutes = {};
  for (const [path, entry] of Object.entries(api)) {
    if (typeof entry === "function") {
      guarded[path] = guard(entry);
      continue;
    }
    const methods: Partial<Record<(typeof API_METHODS)[number], ApiHandler>> = {};
    for (const method of API_METHODS) {
      const handler = entry[method];
      if (handler) methods[method] = guard(handler);
    }
    guarded[path] = methods;
  }
  return guarded;
}

// O(1) per request plus the handler
// INV: `api` handlers are built with route(), which wraps every response (including errors) in secureResponse, so they are mounted directly with no loopback hop
// INV: `api` must not contain "/*"; the HTML bundle stays on the upstream so its responses pass through secureResponse
// INV: maxRequestBodySize caps every body at the socket; route maxBody still caps each route below that
// INV: idleTimeout covers documents and rejected requests; guardRoutes lifts it for authenticated API requests so a quiet model call is not reset. Bun's default of 10s would reset the socket before a lesson step or chat reply is written.
// SEC: binds 127.0.0.1 only. The launch token makes localGuard reject any other Host, a missing API token, and a foreign mutation Origin.
export function servePublic(o: { port: number; api: ApiRoutes; upstream: URL; token: string }): Server<UpstreamSocket> {
  if ("/*" in o.api) throw new Error("the document route belongs on the upstream");
  const bound = { port: 0 };
  const guardedApi = guardRoutes(o.api, o.token, () => bound.port);
  const server = Bun.serve<UpstreamSocket>({
    id: "btg",
    hostname: "127.0.0.1",
    port: o.port,
    maxRequestBodySize: MAX_REQUEST_BYTES,
    idleTimeout: SERVER_IDLE_TIMEOUT_S,
    routes: guardedApi,
    websocket: {
      open(ws) {
        const client = new WebSocket(ws.data.url);
        (client as { binaryType: string }).binaryType = "nodebuffer";
        ws.data.inner = client;
        client.addEventListener("open", () => {
          const queued = ws.data.pending;
          ws.data.pending = [];
          for (const message of queued) client.send(typeof message === "string" ? message : Uint8Array.from(message));
        });
        client.addEventListener("message", (ev) => {
          if (ws.readyState !== WebSocket.OPEN) return;
          const data: unknown = ev.data;
          if (typeof data === "string" || data instanceof Uint8Array || data instanceof ArrayBuffer) ws.send(data);
        });
        const shut = (): void => { if (ws.readyState === WebSocket.OPEN) ws.close(); };
        client.addEventListener("close", shut);
        client.addEventListener("error", shut);
      },
      message(ws, message) {
        const client = ws.data.inner;
        if (client && client.readyState === WebSocket.OPEN) client.send(typeof message === "string" ? message : Uint8Array.from(message));
        else ws.data.pending.push(message);
      },
      close(ws) {
        ws.data.inner?.close();
      },
    },
    async fetch(req, server) {
      const blocked = localGuard(req, `127.0.0.1:${server.port}`, o.token);
      if (blocked) return secureResponse(blocked);
      if ((req.headers.get("upgrade") ?? "").toLowerCase() === "websocket") {
        // SEC: a WebSocket handshake is a GET and carries no launch token, so a foreign page could open one; require the exact app Origin
        if (!originAllowed(req.headers.get("origin"), guardOrigin())) return secureResponse(new Response(null, { status: 403 }));
        const url = new URL(req.url);
        const target = new URL(url.pathname + url.search, o.upstream).href.replace(/^http/, "ws");
        if (server.upgrade(req, { data: { url: target, inner: null, pending: [] } })) return;
        return secureResponse(new Response(null, { status: 400 }));
      }
      const url = new URL(req.url);
      const asset = await readPyodideAsset(url.pathname, req.method);
      if (asset) return secureResponse(asset);
      return proxyDocument(req, o.upstream);
    },
    error() {
      return secureResponse(json({ error: "internal" }, 500));
    },
  });
  const port = server.port ?? 0;
  if (port === 0) throw new Error("listener did not bind");
  bound.port = port;
  return server;
}
